# MusicianApp 
Playing with Music

MusicianApp is an easy way for anyone to get started making original music, by composing, collaborating and even recording, in seconds.  

It's the drum circle of the future!

There’s no software to install, just visit the website and start jamming!  Make music with friends using a Collaboration Room.

Link: https://young-garden-19844.herokuapp.com/

### Home Page

![colabscreenshot](https://user-images.githubusercontent.com/26423462/33974802-6beda5f2-e058-11e7-89b2-d07490dbab04.png)

### Colab Page

![screenshot](https://user-images.githubusercontent.com/26423462/33975148-b68fe79e-e05a-11e7-9746-8a528c087078.png)
